# Telegram Бот-Бухгалтер на тенге 🇰🇿

Функции:
- Учет доходов и расходов
- Продажа товаров и продажи в долг
- Диаграммы расходов и продаж каждое воскресенье
- Уведомления о долгах
- Telegram кнопки (меню)

## Запуск на Render.com (бесплатно)
1. Создай репозиторий на GitHub
2. Загрузи содержимое этого архива (не сам zip)
3. Создай новый Web Service на [https://render.com](https://render.com)
4. Добавь переменные окружения:
    - `BOT_TOKEN` — токен от @BotFather
    - `TZ` — `Asia/Almaty`
5. Build command: `pip install -r requirements.txt`
6. Start command: `python main.py`